common-mimetypes
================

Common MIME types not available in standard library mimetypes module

Package:
  http://pypi.python.org/pypi/common-mimetypes
Project:
  https://github.com/iki/common-mimetypes
Issues:
  https://github.com/iki/common-mimetypes/issues
Updates:
  https://github.com/iki/common-mimetypes/commits/master.atom
Install via `pip <http://www.pip-installer.org>`_:
  ``pip install common-mimetypes``
Install via `easy_install <http://peak.telecommunity.com/DevCenter/EasyInstall>`_:
  ``easy_install common-mimetypes``
Sources via `git <http://git-scm.com/>`_:
  ``git clone https://github.com/iki/common-mimetypes``
Sources via `hg-git <https://github.com/schacon/hg-git>`_:
  ``hg clone git://github.com/iki/common-mimetypes``
